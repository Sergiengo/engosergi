let presupuestos = [];
let movimientos = [];

// ... (El resto de tu código JS sigue igual hasta llegar a la parte de las funciones) ...

function crearPresupuesto() {
    const nombre = document.getElementById('presupuesto-nombre').value;
    const monto = parseFloat(document.getElementById('presupuesto-monto').value);
    presupuestos.push({ nombre, montoOriginal: monto, montoRestante: monto });

    actualizarInterfaz();
    resetearCampos();
}

function registrarIngreso() {
    const nombreIngreso = document.getElementById('nombre-ingreso').value;
    const montoMovimiento = parseFloat(document.getElementById('registro-monto-ingreso').value);
    const fecha = new Date().toISOString().split('T')[0]; // Formato AAAA-MM-DD

    if (nombreIngreso === '' || isNaN(montoMovimiento)) {
        alert('Por favor, ingresa un nombre y un monto válido para el ingreso.');
        return;
    }

    movimientos.push({ tipo: 'Ingreso', nombrePresupuesto: nombreIngreso, montoMovimiento, fecha });
    actualizarInterfaz();
    resetearCampos();
}

function registrarGasto() {
    const nombrePresupuesto = document.getElementById('presupuesto-registro-gasto').value;
    const montoMovimiento = parseFloat(document.getElementById('registro-monto-gasto').value);
    const fecha = new Date().toISOString().split('T')[0]; // Formato AAAA-MM-DD

    const presupuesto = presupuestos.find(p => p.nombre === nombrePresupuesto);
    if (presupuesto && montoMovimiento <= presupuesto.montoRestante) {
        presupuesto.montoRestante -= montoMovimiento;
    } else {
        alert("Gasto inválido o excede el monto restante del presupuesto.");
        return;
    }

    movimientos.push({ tipo: 'Gasto', nombrePresupuesto, montoMovimiento, fecha });
    actualizarInterfaz();
    resetearCampos();
}

// Nueva función para resetear los campos de entrada
function resetearCampos() {
    document.getElementById('presupuesto-nombre').value = '';
    document.getElementById('presupuesto-monto').value = '';
    document.getElementById('nombre-ingreso').value = '';
    document.getElementById('registro-monto-ingreso').value = '';
    document.getElementById('presupuesto-registro-gasto').selectedIndex = 0;
    document.getElementById('registro-monto-gasto').value = '';
}

// ... (El resto de tu código JS continúa) ...


function actualizarInterfaz() {
    mostrarPresupuestos();
    actualizarOpcionesPresupuesto();
    mostrarMovimientos();
}

// ... (El resto de tu código JS sigue igual hasta llegar a la función mostrarPresupuestos) ...

function mostrarPresupuestos() {
    const tablaPresupuestos = document.getElementById('tabla-presupuestos').getElementsByTagName('tbody')[0];
    tablaPresupuestos.innerHTML = '';

    presupuestos.forEach(presupuesto => {
        const fila = tablaPresupuestos.insertRow();
        fila.insertCell(0).textContent = presupuesto.nombre;
        fila.insertCell(1).textContent = `${presupuesto.montoOriginal.toFixed(2)}€`;

        const celdaCantidadRestante = fila.insertCell(2);
        celdaCantidadRestante.textContent = `${presupuesto.montoRestante.toFixed(2)}€`;

        // Cambiar el color de la celda según la cantidad restante
        if (presupuesto.montoRestante > 100) {
            celdaCantidadRestante.style.backgroundColor = '#CCFFCC';
        } else if (presupuesto.montoRestante >= 50) {
            celdaCantidadRestante.style.backgroundColor = '#FFFFCC';
        } else {
            celdaCantidadRestante.style.backgroundColor = '#FFCCCC';
        }
    });
}

// ... (El resto de tu código JS continúa) ...


function actualizarOpcionesPresupuesto() {
    const selectGasto = document.getElementById('presupuesto-registro-gasto');
    selectGasto.innerHTML = '';

    presupuestos.forEach(presupuesto => {
        const optionGasto = document.createElement('option');
        optionGasto.value = presupuesto.nombre;
        optionGasto.textContent = presupuesto.nombre;
        selectGasto.appendChild(optionGasto);
    });
}

function mostrarMovimientos() {
    const tablaMovimientos = document.getElementById('tabla-gastos').getElementsByTagName('tbody')[0];
    tablaMovimientos.innerHTML = '';

    movimientos.forEach(movimiento => {
        const fila = tablaMovimientos.insertRow();
        fila.className = movimiento.tipo.toLowerCase();
        fila.insertCell(0).textContent = movimiento.tipo;
        fila.insertCell(1).textContent = movimiento.nombrePresupuesto;
        fila.insertCell(2).textContent = `${movimiento.montoMovimiento.toFixed(2)}€`;
        fila.insertCell(3).textContent = movimiento.fecha;
    });
}

window.onload = actualizarInterfaz;